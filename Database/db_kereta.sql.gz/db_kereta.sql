-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 28 Mei 2018 pada 09.41
-- Versi Server: 10.1.22-MariaDB
-- PHP Version: 7.0.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_kereta`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_mydata`
--

CREATE TABLE `tb_mydata` (
  `NomorInduk` int(8) NOT NULL,
  `NoPemesanan` int(4) NOT NULL,
  `Nama` varchar(40) NOT NULL,
  `Asal` varchar(20) NOT NULL,
  `Tujuan` varchar(20) NOT NULL,
  `Tanggal Keberangkatan` varchar(20) NOT NULL,
  `Kelas Kereta` varchar(20) NOT NULL,
  `Kereta` varchar(10) NOT NULL,
  `TotalBayar` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_mydata`
--

INSERT INTO `tb_mydata` (`NomorInduk`, `NoPemesanan`, `Nama`, `Asal`, `Tujuan`, `Tanggal Keberangkatan`, `Kelas Kereta`, `Kereta`, `TotalBayar`) VALUES
(17062111, 8923, 'Jokowi', 'JAKARTA', 'WIKRAMA', 'Senin, 28 Mei 2018', 'EXECUTIVE', 'JBD-W1', '30.000,00'),
(11706212, 4297, 'Jhon', 'WIKRAMA', 'BOGOR', 'Rabu, 09 Mei 2018', 'ECONOMIC', 'JBD-W3', '10.000,00'),
(11706211, 8795, 'Steven', 'TANGGERANG', 'WIKRAMA', 'Kamis, 10 Mei 2018', 'REGULAR', 'TB-W2', '25.000,00'),
(11706213, 4618, 'Beryl', 'BOGOR', 'WIKRAMA', 'Sabtu, 26 Mei 2018', 'EXECUTIVE', 'JBD-W1', '30.000,00'),
(11706214, 1402, 'Ardi', 'WIKRAMA', 'BOGOR', 'Sabtu, 26 Mei 2018', 'REGULAR', 'JBD-W2', '20.000,00'),
(11706213, 3536, 'Arief', 'BEKASI', 'WIKRAMA', 'Kamis, 10 Mei 2018', 'REGULAR', 'TB-W2', '25.000,00'),
(11908070, 2952, 'Kunedi', 'WIKRAMA', 'BEKASI', 'Kamis, 10 Mei 2018', 'EXECUTIVE', 'TB-W1', '35.000,00'),
(11708900, 8043, 'Muhammad', 'WIKRAMA', 'JAKARTA', 'Senin, 28 Mei 2018', 'REGULAR', 'JBD-W2', '20.000,00');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
